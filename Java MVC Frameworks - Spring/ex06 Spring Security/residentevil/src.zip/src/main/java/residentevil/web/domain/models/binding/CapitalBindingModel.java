package residentevil.web.domain.models.binding;

/**
 * Created by Neycho Damgaliev on 3/19/2019.
 */
public class CapitalBindingModel {
    private Long id;

    public CapitalBindingModel() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
